module ConflictCategories

	def findConflictCause(build)
		raise NotImplementedError
	end

end